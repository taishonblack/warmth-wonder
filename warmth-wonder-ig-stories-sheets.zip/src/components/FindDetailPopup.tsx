import { Heart, UserPlus, UserCheck, X } from "lucide-react";
import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Dialog, DialogClose, DialogContent } from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/useAuth";
import { useFollows } from "@/hooks/useFollows";

export type FindDetail = {
  id: string;
  image: string;
  posterName: string;
  posterAvatar: string;
  posterUserId?: string;
  caption: string;
  marketName: string;
  thanksCount: number;
  timestamp: string;
  userHasThanked?: boolean;
};

interface FindDetailPopupProps {
  isOpen: boolean;
  onClose: () => void;
  find: FindDetail | null;
  onToggleThanks?: (findId: string) => Promise<void> | void;
}

export function FindDetailPopup({ isOpen, onClose, find, onToggleThanks }: FindDetailPopupProps) {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { isFollowing, toggleFollow } = useFollows();

  const [optimisticThanked, setOptimisticThanked] = useState<boolean>(false);

  const thanked = useMemo(() => {
    if (!find) return false;
    if (typeof find.userHasThanked === "boolean") return find.userHasThanked;
    return optimisticThanked;
  }, [find, optimisticThanked]);

  if (!find) return null;

  const canFollow = !!find.posterUserId && find.posterUserId !== user?.id;
  const following = canFollow ? isFollowing(find.posterUserId!) : false;

  const handleMoreClick = () => {
    onClose();
    navigate("/finds");
  };

  const handlePosterClick = () => {
    if (!find.posterUserId) return;
    onClose();
    navigate(`/u/${find.posterUserId}`);
  };

  const handleThanks = async () => {
    if (onToggleThanks) {
      await onToggleThanks(find.id);
      return;
    }
    // Fallback optimistic mode for mock finds
    setOptimisticThanked((v) => !v);
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md p-0 overflow-hidden bg-card border-border">
        {/* Image */}
        <div className="relative aspect-square">
          <img src={find.image} alt="Find" className="w-full h-full object-cover" />
          <DialogClose className="absolute top-3 right-3 w-8 h-8 rounded-full bg-foreground/50 backdrop-blur-sm flex items-center justify-center text-primary-foreground hover:bg-foreground/70 transition-colors">
            <X className="w-4 h-4" />
          </DialogClose>
        </div>

        {/* Content */}
        <div className="p-4 space-y-3">
          {/* Poster info */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handlePosterClick}
              className={cn(
                "relative rounded-full",
                find.posterUserId ? "hover:opacity-90 transition-opacity" : ""
              )}
            >
              <img
                src={find.posterAvatar}
                alt={find.posterName}
                className="w-10 h-10 rounded-full object-cover ring-2 ring-blush"
              />
            </button>

            <div className="flex-1 min-w-0">
              <button
                type="button"
                onClick={handlePosterClick}
                className={cn(
                  "font-medium text-sm text-foreground truncate text-left",
                  find.posterUserId ? "hover:underline" : ""
                )}
              >
                {find.posterName}
              </button>
              <p className="text-xs text-muted-foreground">{find.timestamp}</p>
            </div>

            {canFollow && (
              <button
                type="button"
                onClick={() => toggleFollow(find.posterUserId!)}
                className={cn(
                  "shrink-0 inline-flex items-center gap-1.5 px-3 py-2 rounded-full text-xs font-medium transition-colors",
                  following
                    ? "bg-muted text-foreground hover:bg-muted/80"
                    : "bg-primary text-primary-foreground hover:bg-primary/90"
                )}
              >
                {following ? <UserCheck className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
                {following ? "Following" : "Follow"}
              </button>
            )}
          </div>

          {/* Caption */}
          <p className="text-sm text-foreground leading-relaxed line-clamp-3">{find.caption}</p>

          {/* Market Tag */}
          <div className="inline-flex items-center gap-1 px-3 py-1.5 bg-blush/50 rounded-full text-xs font-medium text-primary">
            📍 {find.marketName}
          </div>

          {/* Actions */}
          <div className="flex items-center justify-between pt-2 border-t border-border">
            <button
              onClick={handleThanks}
              className={cn(
                "flex items-center gap-1.5 text-sm transition-colors",
                thanked ? "text-accent" : "text-muted-foreground hover:text-accent"
              )}
            >
              <Heart className="w-5 h-5" fill={thanked ? "currentColor" : "none"} />
              <span>{thanked ? find.thanksCount + 1 : find.thanksCount} thanks</span>
            </button>

            <button
              onClick={handleMoreClick}
              className="px-4 py-2 bg-primary text-primary-foreground rounded-full text-sm font-medium hover:bg-primary/90 transition-colors"
            >
              More
            </button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
