import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Loader2, Users } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";

type MiniUser = {
  id: string;
  name: string;
  avatar: string;
  bio?: string | null;
};

export type UserListMode = "followers" | "following";

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  userId: string;
  mode: UserListMode;
};

export function UserListSheet({ open, onOpenChange, userId, mode }: Props) {
  const title = useMemo(() => (mode === "followers" ? "Followers" : "Following"), [mode]);
  const [loading, setLoading] = useState(false);
  const [users, setUsers] = useState<MiniUser[]>([]);

  useEffect(() => {
    if (!open || !userId) return;

    let cancelled = false;

    const run = async () => {
      setLoading(true);
      try {
        // Fetch IDs from follows table for the requested user
        const query = supabase
          .from("follows")
          .select(mode === "followers" ? "follower_id" : "following_id")
          .eq(mode === "followers" ? "following_id" : "follower_id", userId);

        const { data, error } = await query;
        if (error) throw error;

        const ids = (data || []).map((r: any) =>
          mode === "followers" ? r.follower_id : r.following_id
        );

        if (ids.length === 0) {
          if (!cancelled) setUsers([]);
          return;
        }

        const { data: profilesData } = await supabase
          .from("profiles")
          .select("user_id, display_name, avatar_url, bio")
          .in("user_id", ids)
          .limit(200);

        const byId = new Map<string, any>();
        (profilesData || []).forEach((p: any) => byId.set(p.user_id, p));

        const resolved: MiniUser[] = ids.map((id: string) => {
          const p = byId.get(id);
          return {
            id,
            name: p?.display_name || "Nearish Member",
            avatar: p?.avatar_url || `https://i.pravatar.cc/150?u=${id}`,
            bio: p?.bio || null,
          };
        });

        if (!cancelled) setUsers(resolved);
      } catch (e) {
        console.error("Error loading user list:", e);
        if (!cancelled) setUsers([]);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    run();

    return () => {
      cancelled = true;
    };
  }, [open, userId, mode]);

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="bottom" className="p-0 rounded-t-3xl">
        <div className="mx-auto mt-2 h-1 w-12 rounded-full bg-muted" />
        <SheetHeader className="px-4 pt-4 pb-3">
          <SheetTitle className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            {title}
          </SheetTitle>
        </SheetHeader>

        <div className="px-4 pb-6 max-h-[70vh] overflow-auto">
          {loading && (
            <div className="flex items-center justify-center py-10">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          )}

          {!loading && users.length === 0 && (
            <div className="text-center py-10 text-sm text-muted-foreground">
              No {mode} yet.
            </div>
          )}

          {!loading && users.length > 0 && (
            <div className="space-y-3">
              {users.map((u) => (
                <Link
                  key={u.id}
                  to={`/u/${u.id}`}
                  onClick={() => onOpenChange(false)}
                  className={cn(
                    "flex items-center gap-3 p-3 rounded-2xl",
                    "bg-card hover:bg-muted/40 transition-colors"
                  )}
                >
                  <img src={u.avatar} alt={u.name} className="w-12 h-12 rounded-full object-cover" />
                  <div className="min-w-0">
                    <div className="font-medium text-foreground truncate">{u.name}</div>
                    <div className="text-xs text-muted-foreground truncate">
                      {u.bio || "Sharing local goodness on Nearish."}
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}
