import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, Loader2, Settings } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useFollows } from "@/hooks/useFollows";
import { useIsMobile } from "@/hooks/use-mobile";
import { FindGridItem } from "@/components/FindGridItem";
import { FindDetailPopup, FindDetail } from "@/components/FindDetailPopup";
import { useTrustBadges } from "@/hooks/useTrustBadges";
import { cn } from "@/lib/utils";
import { UserListSheet } from "@/components/UserListSheet";

type ProfileRow = {
  user_id: string;
  display_name: string | null;
  avatar_url: string | null;
  bio: string | null;
};

type FindRow = {
  id: string;
  user_id: string;
  caption: string;
  market_name: string;
  images: string[];
  created_at: string;
};

export default function UserProfile() {
  const { userId } = useParams<{ userId: string }>();
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const { user } = useAuth();
  const { isFollowing, toggleFollow, getFollowerCount, getFollowingCount } = useFollows();
  const { badges } = useTrustBadges(userId || "");

  const [profile, setProfile] = useState<ProfileRow | null>(null);
  const [finds, setFinds] = useState<FindDetail[]>([]);
  const [counts, setCounts] = useState<{ followers: number; following: number; finds: number; thanks: number }>({
    followers: 0,
    following: 0,
    finds: 0,
    thanks: 0,
  });
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<FindDetail | null>(null);
  const [followersOpen, setFollowersOpen] = useState(false);
  const [followingOpen, setFollowingOpen] = useState(false);
  const [followersOpen, setFollowersOpen] = useState(false);
  const [followingOpen, setFollowingOpen] = useState(false);

  const canFollow = !!userId && userId !== user?.id;
  const following = canFollow ? isFollowing(userId!) : false;

  useEffect(() => {
    if (!userId) return;

    const run = async () => {
      setLoading(true);
      try {
        const { data: profileData } = await supabase
          .from("profiles")
          .select("user_id, display_name, avatar_url, bio")
          .eq("user_id", userId)
          .maybeSingle();

        setProfile((profileData as any) || null);

        const { data: findsData } = await supabase
          .from("finds")
          .select("id, user_id, caption, market_name, images, created_at")
          .eq("user_id", userId)
          .order("created_at", { ascending: false });

        const formatted: FindDetail[] = (findsData as any[] | null)?.map((f) => ({
          id: f.id,
          image: (f.images?.[0] as string) || "",
          posterName: profileData?.display_name || "Nearish Member",
          posterAvatar: profileData?.avatar_url || `https://i.pravatar.cc/150?u=${userId}`,
          posterUserId: userId,
          caption: f.caption,
          marketName: f.market_name,
          thanksCount: 0,
          timestamp: formatTimestamp(new Date(f.created_at)),
        })) || [];

        // Thanks received count (sum of thanks on their finds)
        const findIds = (findsData as any[] | null)?.map((f) => f.id) || [];
        let thanksReceived = 0;
        if (findIds.length > 0) {
          const { data: thanksData } = await supabase
            .from("thanks")
            .select("find_id")
            .in("find_id", findIds);
          thanksReceived = thanksData?.length || 0;

          // Also attach counts per find for popup
          const byFind = new Map<string, number>();
          (thanksData || []).forEach((t: any) => byFind.set(t.find_id, (byFind.get(t.find_id) || 0) + 1));
          formatted.forEach((fd) => (fd.thanksCount = byFind.get(fd.id) || 0));
        }

        const [followersCount, followingCount] = await Promise.all([
          getFollowerCount(userId),
          getFollowingCount(userId),
        ]);

        setCounts({
          followers: followersCount,
          following: followingCount,
          finds: formatted.length,
          thanks: thanksReceived,
        });

        setFinds(formatted);
      } finally {
        setLoading(false);
      }
    };

    run();
  }, [userId]);

  const displayName = useMemo(() => {
    return profile?.display_name || "Nearish Member";
  }, [profile]);

  if (!userId) return null;

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-background/95 backdrop-blur-sm py-4 px-4 flex items-center justify-between border-b border-border">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate(-1)}
            className="p-2 -m-2 text-muted-foreground hover:text-foreground transition-colors"
            aria-label="Back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="font-serif text-lg font-bold text-primary leading-tight">{displayName}</div>
            <div className="text-xs text-muted-foreground">Community member</div>
          </div>
        </div>

        {userId === user?.id ? (
          <Link to="/settings" className="p-2 -m-2 text-muted-foreground hover:text-foreground transition-colors">
            <Settings className="w-5 h-5" />
          </Link>
        ) : (
          <div />
        )}
      </header>

      <div className="max-w-4xl mx-auto">
        {/* Top card */}
        <div className="px-4 py-6">
          <div className="flex items-center gap-4">
            <img
              src={profile?.avatar_url || `https://i.pravatar.cc/150?u=${userId}`}
              alt={displayName}
              className="w-20 h-20 rounded-full object-cover ring-4 ring-blush"
            />
            <div className="flex-1">
              <div className="font-serif text-xl font-semibold text-foreground">{displayName}</div>
              {profile?.bio ? (
                <p className="mt-1 text-sm text-muted-foreground leading-relaxed line-clamp-2">{profile.bio}</p>
              ) : (
                <p className="mt-1 text-sm text-muted-foreground">Sharing local goodness on Nearish.</p>
              )}

              <div className="flex gap-4 mt-3 text-sm">
                <span className="text-foreground">
                  <strong>{counts.finds}</strong> <span className="text-muted-foreground">finds</span>
                </span>
                <span className="text-foreground">
                  <strong>{counts.thanks}</strong> <span className="text-muted-foreground">thanks</span>
                </span>
                <button
                  type="button"
                  onClick={() => setFollowersOpen(true)}
                  className="text-foreground hover:opacity-80 transition-opacity"
                  aria-label="Show followers"
                >
                  <strong>{counts.followers}</strong> <span className="text-muted-foreground">followers</span>
                </button>
                <button
                  type="button"
                  onClick={() => setFollowingOpen(true)}
                  className="text-foreground hover:opacity-80 transition-opacity"
                  aria-label="Show following"
                >
                  <strong>{counts.following}</strong> <span className="text-muted-foreground">following</span>
                </button>
              </div>
            </div>
          </div>

          {canFollow && (
            <button
              onClick={() => toggleFollow(userId)}
              className={cn(
                "mt-4 w-full py-3 rounded-xl font-medium transition-colors",
                following
                  ? "bg-muted text-foreground hover:bg-muted/80"
                  : "bg-primary text-primary-foreground hover:bg-primary/90"
              )}
            >
              {following ? "Following" : "Follow"}
            </button>
          )}

          {/* Badges */}
          {badges.length > 0 && (
            <div className="mt-4 flex flex-wrap gap-2">
              {badges.map((b) => (
                <span
                  key={b.label}
                  className="px-3 py-1.5 rounded-full text-xs font-medium bg-primary/15 text-primary"
                  title={b.description}
                >
                  {b.emoji} {b.label}
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Finds grid */}
        <div className={cn(isMobile ? "px-3 py-3" : "px-4 pb-8")}>
          <div
            className={
              isMobile
                ? "grid grid-cols-3 gap-1"
                : "grid grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3"
            }
          >
            {finds.map((f) => (
              <FindGridItem
                key={f.id}
                image={f.image}
                posterName={f.posterName}
                posterAvatar={f.posterAvatar}
                caption={f.caption}
                marketName={f.marketName}
                thanksCount={f.thanksCount}
                aspectRatio="square"
                onClick={() => setSelected(f)}
              />
            ))}
          </div>

          {finds.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <p className="text-sm">No finds yet.</p>
            </div>
          )}
        </div>
      </div>

      <UserListSheet open={followersOpen} onOpenChange={setFollowersOpen} userId={userId} mode="followers" />
      <UserListSheet open={followingOpen} onOpenChange={setFollowingOpen} userId={userId} mode="following" />

      <FindDetailPopup isOpen={!!selected} onClose={() => setSelected(null)} find={selected} />
    </div>
  );
}

function formatTimestamp(createdAt: Date) {
  const now = new Date();
  const diffMs = now.getTime() - createdAt.getTime();
  const diffMinutes = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMinutes < 1) return "Just now";
  if (diffMinutes < 60) return `${diffMinutes}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  return `${diffDays}d ago`;
}
