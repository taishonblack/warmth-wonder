import { Settings, ChevronRight, MapPin, Calendar, ArrowLeft, Loader2 } from "lucide-react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useEffect, useMemo, useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useProfile } from "@/hooks/useProfile";
import { useAuth } from "@/hooks/useAuth";
import { useFollows } from "@/hooks/useFollows";
import { useTrustBadges } from "@/hooks/useTrustBadges";
import { supabase } from "@/integrations/supabase/client";
import { FindGridItem } from "@/components/FindGridItem";
import { FindDetailPopup, FindDetail } from "@/components/FindDetailPopup";
import { UserListSheet } from "@/components/UserListSheet";

type MiniUser = { id: string; name: string; avatar: string };

export default function Profile() {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const { profile, preferredMarkets, loading: profileLoading, saving, updateProfile, togglePreferredMarket } = useProfile();
  const { following, followers, getFollowingCount, getFollowerCount } = useFollows();
  const { badges } = useTrustBadges(user?.id || "");

  const [isEditing, setIsEditing] = useState(false);
  const [localBirthday, setLocalBirthday] = useState("");
  const [localZipCode, setLocalZipCode] = useState("");
  const [localRadius, setLocalRadius] = useState([25]);

  const [myFinds, setMyFinds] = useState<FindDetail[]>([]);
  const [counts, setCounts] = useState<{ finds: number; thanks: number; followers: number; following: number }>({
    finds: 0,
    thanks: 0,
    followers: 0,
    following: 0,
  });
  const [followingUsers, setFollowingUsers] = useState<MiniUser[]>([]);
  const [selected, setSelected] = useState<FindDetail | null>(null);
  const [dataLoading, setDataLoading] = useState(true);
  const [followersOpen, setFollowersOpen] = useState(false);
  const [followingOpen, setFollowingOpen] = useState(false);
  const [followersOpen, setFollowersOpen] = useState(false);
  const [followingOpen, setFollowingOpen] = useState(false);

  // Sync local state with profile data
  useEffect(() => {
    if (profile) {
      setLocalBirthday(profile.birthday || "");
      setLocalZipCode(profile.zip_code || "");
      setLocalRadius([profile.radius_miles || 25]);
    }
  }, [profile]);

  // Redirect to auth if not logged in
  if (!authLoading && !user) {
    return <Navigate to="/auth" replace />;
  }

  const handleSaveProfile = async () => {
    await updateProfile({
      birthday: localBirthday || null,
      zip_code: localZipCode || null,
      radius_miles: localRadius[0],
    });
    setIsEditing(false);
  };

  const handleRadiusChange = async (value: number[]) => {
    setLocalRadius(value);
    // Auto-save radius changes
    await updateProfile({ radius_miles: value[0] });
  };

  useEffect(() => {
    if (!user) return;

    const run = async () => {
      setDataLoading(true);
      try {
        // My finds
        const { data: findsData } = await supabase
          .from("finds")
          .select("id, caption, market_name, images, created_at")
          .eq("user_id", user.id)
          .order("created_at", { ascending: false });

        const formatted: FindDetail[] = (findsData as any[] | null)?.map((f) => ({
          id: f.id,
          image: (f.images?.[0] as string) || "",
          posterName: profile?.display_name || user.email?.split("@")[0] || "You",
          posterAvatar: profile?.avatar_url || `https://i.pravatar.cc/150?u=${user.id}`,
          posterUserId: user.id,
          caption: f.caption,
          marketName: f.market_name,
          thanksCount: 0,
          timestamp: formatTimestamp(new Date(f.created_at)),
        })) || [];

        // Thanks received
        const findIds = (findsData as any[] | null)?.map((f) => f.id) || [];
        let thanksReceived = 0;
        if (findIds.length > 0) {
          const { data: thanksData } = await supabase
            .from("thanks")
            .select("find_id")
            .in("find_id", findIds);
          thanksReceived = thanksData?.length || 0;

          const byFind = new Map<string, number>();
          (thanksData || []).forEach((t: any) => byFind.set(t.find_id, (byFind.get(t.find_id) || 0) + 1));
          formatted.forEach((fd) => (fd.thanksCount = byFind.get(fd.id) || 0));
        }

        // Follow counts
        const [followersCount, followingCount] = await Promise.all([
          getFollowerCount(user.id),
          getFollowingCount(user.id),
        ]);

        setCounts({
          finds: formatted.length,
          thanks: thanksReceived,
          followers: followersCount,
          following: followingCount,
        });

        setMyFinds(formatted);

        // Following list (first 12)
        if (following.length > 0) {
          const ids = following.slice(0, 12);
          const { data: profilesData } = await supabase
            .from("profiles")
            .select("user_id, display_name, avatar_url")
            .in("user_id", ids);

          setFollowingUsers(
            (profilesData || []).map((p: any) => ({
              id: p.user_id,
              name: p.display_name || "Nearish Member",
              avatar: p.avatar_url || `https://i.pravatar.cc/150?u=${p.user_id}`,
            }))
          );
        } else {
          setFollowingUsers([]);
        }
      } finally {
        setDataLoading(false);
      }
    };

    run();
  }, [user?.id, profile?.display_name, profile?.avatar_url, following.length]);

  const displayName = useMemo(() => {
    return profile?.display_name || user?.email?.split("@")[0] || "User";
  }, [profile?.display_name, user?.email]);

  if (authLoading || profileLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-background/95 backdrop-blur-sm py-4 px-4 flex items-center justify-between border-b border-border">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate(-1)}
            className="p-2 -m-2 text-muted-foreground hover:text-foreground transition-colors md:hidden"
            aria-label="Back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="font-serif text-2xl font-bold text-primary">Profile</h1>
        </div>
        <Link to="/settings" className="p-2 -m-2 text-muted-foreground hover:text-foreground transition-colors">
          <Settings className="w-5 h-5" />
        </Link>
      </header>

      <div className="max-w-4xl mx-auto">
        {/* Profile Info */}
        <div className="px-4 py-6">
          <div className="flex items-center gap-4">
            <div className="relative">
              <img
                src={profile?.avatar_url || `https://i.pravatar.cc/150?u=${user?.id}`}
                alt="Profile"
                className="w-20 h-20 rounded-full object-cover ring-4 ring-blush"
              />
              <span className="absolute bottom-0 right-0 w-6 h-6 bg-primary rounded-full flex items-center justify-center text-xs text-primary-foreground">
                ✓
              </span>
            </div>
            <div className="flex-1">
              <h2 className="font-serif text-xl font-semibold text-foreground">{displayName}</h2>
              <p className="text-sm text-muted-foreground">{user?.email}</p>
              <div className="flex gap-4 mt-2 text-sm">
                <span className="text-foreground">
                  <strong>{counts.finds}</strong> <span className="text-muted-foreground">finds</span>
                </span>
                <span className="text-foreground">
                  <strong>{counts.thanks}</strong> <span className="text-muted-foreground">thanks</span>
                </span>
                <button
                  type="button"
                  onClick={() => setFollowingOpen(true)}
                  className="text-foreground hover:opacity-80 transition-opacity"
                  aria-label="Show following"
                >
                  <strong>{counts.following}</strong> <span className="text-muted-foreground">following</span>
                </button>
                <button
                  type="button"
                  onClick={() => setFollowersOpen(true)}
                  className="text-foreground hover:opacity-80 transition-opacity"
                  aria-label="Show followers"
                >
                  <strong>{counts.followers}</strong> <span className="text-muted-foreground">followers</span>
                </button>
              </div>
            </div>
          </div>

          {/* Trust badges */}
          {badges.length > 0 && (
            <div className="mt-4 flex flex-wrap gap-2">
              {badges.map((b) => (
                <Badge key={b.label} variant="secondary" title={b.description}>
                  {b.emoji} {b.label}
                </Badge>
              ))}
            </div>
          )}

          <Button
            variant="outline"
            className="mt-4 w-full"
            onClick={() => (isEditing ? handleSaveProfile() : setIsEditing(true))}
            disabled={saving}
          >
            {saving ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Saving...
              </>
            ) : isEditing ? (
              "Save Profile"
            ) : (
              "Edit Profile"
            )}
          </Button>
        </div>

        {/* Account Information (editable) */}
        {isEditing && (
          <section className="px-4 py-4 border-t border-border">
            <h3 className="font-serif text-lg font-semibold text-foreground mb-4">Account Information</h3>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="birthday" className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-secondary" />
                    Birthday
                  </Label>
                  <Input id="birthday" type="date" value={localBirthday} onChange={(e) => setLocalBirthday(e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="zipCode" className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-secondary" />
                    Zip Code
                  </Label>
                  <Input
                    id="zipCode"
                    type="text"
                    value={localZipCode}
                    onChange={(e) => setLocalZipCode(e.target.value)}
                    placeholder="Enter your zip code"
                    maxLength={10}
                  />
                </div>
              </div>
            </div>
          </section>
        )}

        {/* Discovery Radius - 0-100 */}
        <section className="px-4 py-4 border-t border-border">
          <div className="flex items-center gap-2 mb-3">
            <MapPin className="w-4 h-4 text-secondary" />
            <h3 className="font-serif text-lg font-semibold text-foreground">Discovery Radius</h3>
          </div>
          <p className="text-sm text-muted-foreground mb-4">
            How far to look for markets and finds: <strong>{localRadius[0]} miles</strong>
          </p>
          <Slider value={localRadius} onValueChange={handleRadiusChange} min={0} max={100} step={5} />
        </section>

        {/* Following */}
        <section className="px-4 py-4 border-t border-border">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-serif text-lg font-semibold text-foreground">Following</h3>
            <Link to="/" className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-1">
              See more <ChevronRight className="w-4 h-4" />
            </Link>
          </div>

          {followingUsers.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {followingUsers.map((u) => (
                <button
                  key={u.id}
                  onClick={() => navigate(`/u/${u.id}`)}
                  className="flex items-center gap-3 p-3 rounded-2xl bg-card border border-border hover:bg-muted/40 transition-colors text-left"
                >
                  <img src={u.avatar} alt={u.name} className="w-10 h-10 rounded-full object-cover" />
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-foreground truncate">{u.name}</div>
                    <div className="text-xs text-muted-foreground">Following</div>
                  </div>
                </button>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">You're not following anyone yet.</p>
          )}
        </section>

        {/* My Finds */}
        <section className="px-4 py-4 border-t border-border pb-24 md:pb-10">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-serif text-lg font-semibold text-foreground">My Finds</h3>
            <Link to="/finds" className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-1">
              Open feed <ChevronRight className="w-4 h-4" />
            </Link>
          </div>

          {dataLoading ? (
            <div className="flex items-center justify-center py-10">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          ) : myFinds.length > 0 ? (
            <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-1 md:gap-3">
              {myFinds.slice(0, 12).map((f) => (
                <FindGridItem
                  key={f.id}
                  image={f.image}
                  posterName={f.posterName}
                  posterAvatar={f.posterAvatar}
                  caption={f.caption}
                  marketName={f.marketName}
                  thanksCount={f.thanksCount}
                  aspectRatio="square"
                  onClick={() => setSelected(f)}
                />
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">No finds yet. Share your first one from the Finds tab.</p>
          )}
        </section>
      </div>

      {user?.id && (
        <>
          <UserListSheet
            open={followingOpen}
            onOpenChange={setFollowingOpen}
            userId={user.id}
            mode="following"
          />
          <UserListSheet
            open={followersOpen}
            onOpenChange={setFollowersOpen}
            userId={user.id}
            mode="followers"
          />
        </>
      )}

      <FindDetailPopup isOpen={!!selected} onClose={() => setSelected(null)} find={selected} />
    </div>
  );
}

function formatTimestamp(createdAt: Date) {
  const now = new Date();
  const diffMs = now.getTime() - createdAt.getTime();
  const diffMinutes = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMinutes < 1) return "Just now";
  if (diffMinutes < 60) return `${diffMinutes}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  return `${diffDays}d ago`;
}
