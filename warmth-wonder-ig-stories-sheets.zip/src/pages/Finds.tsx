import { useState } from "react";
import { Loader2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { FindGridItem } from "@/components/FindGridItem";
import { FindDetailPopup } from "@/components/FindDetailPopup";
import { useIsMobile } from "@/hooks/use-mobile";
import { useFinds } from "@/hooks/useFinds";

// Import images for fallback/mock data
import find1 from "@/assets/find-1.jpg";
import find2 from "@/assets/find-2.jpg";
import find3 from "@/assets/find-3.jpg";
import find4 from "@/assets/find-4.jpg";
import find5 from "@/assets/find-5.jpg";
import find6 from "@/assets/find-6.jpg";

const mockFinds = [
  {
    id: "mock-1",
    author: {
      name: "Sarah Chen",
      avatar: "https://i.pravatar.cc/150?img=1",
      userId: "mock-user-1",
    },
    images: [find1],
    caption:
      "Found the most beautiful farm-fresh eggs at Union Square today! The yolks are so vibrant and orange. Perfect for weekend breakfast 🍳",
    marketName: "Union Square Greenmarket",
    thanksCount: 24,
    timestamp: "2 hours ago",
  },
  {
    id: "mock-2",
    author: {
      name: "Marcus Rivera",
      avatar: "https://i.pravatar.cc/150?img=3",
      userId: "mock-user-2",
    },
    images: [find2, find6],
    caption:
      "These sunflowers just made my whole day! The flower vendor at Grand Army is always so lovely. Got fresh herbs too!",
    marketName: "Grand Army Plaza Market",
    thanksCount: 56,
    timestamp: "5 hours ago",
  },
  {
    id: "mock-3",
    author: {
      name: "Emma Thompson",
      avatar: "https://i.pravatar.cc/150?img=5",
      userId: "mock-user-3",
    },
    images: [find3],
    caption:
      "Artisan cheese heaven 🧀 This aged gouda from the local dairy is incredible. They've been making it for three generations!",
    marketName: "Chelsea Market",
    thanksCount: 89,
    timestamp: "1 day ago",
  },
  {
    id: "mock-4",
    author: {
      name: "David Kim",
      avatar: "https://i.pravatar.cc/150?img=8",
      userId: "mock-user-4",
    },
    images: [find4, find5],
    caption:
      "Peak strawberry season has arrived! These are so sweet you don't even need to add sugar. Also grabbed some homemade preserves.",
    marketName: "Smorgasburg",
    thanksCount: 112,
    timestamp: "2 days ago",
  },
];

type PopupFind = {
  id: string;
  image: string;
  posterName: string;
  posterAvatar: string;
  posterUserId?: string;
  caption: string;
  marketName: string;
  thanksCount: number;
  timestamp: string;
  userHasThanked?: boolean;
};

export default function Finds() {
  const isMobile = useIsMobile();
  const navigate = useNavigate();
  const { finds, loading, toggleThanks } = useFinds();
  const [selected, setSelected] = useState<PopupFind | null>(null);

  // Use real finds if available, otherwise show mock data
  const displayFinds = finds.length > 0 ? finds : mockFinds;

  const popupFinds: PopupFind[] = displayFinds.map((f: any) => ({
    id: f.id,
    image: (f.images?.[0] as string) || f.image,
    posterName: f.author?.name || f.posterName || "Nearish Member",
    posterAvatar: f.author?.avatar || f.posterAvatar || "https://i.pravatar.cc/150?img=12",
    posterUserId: f.author?.userId,
    caption: f.caption,
    marketName: f.marketName,
    thanksCount: f.thanksCount || 0,
    timestamp: f.timestamp || "",
    userHasThanked: f.userHasThanked,
  }));

  const stories = (() => {
    const seen = new Set<string>();
    const out: { userId?: string; name: string; avatar: string }[] = [];
    for (const f of popupFinds) {
      const key = f.posterUserId || f.posterName;
      if (seen.has(key)) continue;
      seen.add(key);
      out.push({ userId: f.posterUserId, name: f.posterName, avatar: f.posterAvatar });
      if (out.length >= 18) break;
    }
    return out;
  })();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      {isMobile ? (
        <header className="sticky top-0 z-30 bg-background/95 backdrop-blur-sm border-b border-border">
          <div className="py-3 px-4">
            <div className="flex items-center justify-between">
              <h1 className="font-serif text-2xl font-bold text-primary">Finds</h1>
              <span className="text-xs text-muted-foreground">nearish</span>
            </div>
          </div>

          {/* Stories row */}
          <div className="px-3 pb-3 overflow-x-auto">
            <div className="flex gap-3">
              {stories.map((s, idx) => (
                <button
                  key={`${s.name}-${idx}`}
                  className="flex flex-col items-center gap-1 min-w-[68px]"
                  onClick={() => {
                    if (s.userId) navigate(`/u/${s.userId}`);
                  }}
                >
                  <div className="p-[2px] rounded-full bg-gradient-to-tr from-primary/70 via-blush to-primary/30">
                    <img
                      src={s.avatar}
                      alt={s.name}
                      className="w-14 h-14 rounded-full object-cover bg-card"
                    />
                  </div>
                  <div className="text-[11px] text-muted-foreground truncate w-full text-center">
                    {s.name.split(" ")[0]}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </header>
      ) : (
        <div className="mb-6">
          <h1 className="font-serif text-3xl font-bold text-primary">Finds</h1>
          <p className="text-muted-foreground mt-1">A photo-first feed from your community</p>
          <div className="mt-4 flex gap-3 overflow-x-auto pb-2">
            {stories.map((s, idx) => (
              <Link
                key={`${s.name}-${idx}`}
                to={s.userId ? `/u/${s.userId}` : "#"}
                className="flex flex-col items-center gap-1 min-w-[68px]"
              >
                <div className="p-[2px] rounded-full bg-gradient-to-tr from-primary/70 via-blush to-primary/30">
                  <img src={s.avatar} alt={s.name} className="w-14 h-14 rounded-full object-cover" />
                </div>
                <div className="text-[11px] text-muted-foreground truncate w-full text-center">{s.name.split(" ")[0]}</div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Loading state */}
      {loading && (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      )}

      {/* Instagram-style grid */}
      {!loading && (
        <div
          className={
            isMobile
              ? "px-3 py-3 grid grid-cols-3 gap-1"
              : "grid grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3"
          }
        >
          {popupFinds.map((f) => (
            <FindGridItem
              key={f.id}
              image={f.image}
              posterName={f.posterName}
              posterAvatar={f.posterAvatar}
              caption={f.caption}
              marketName={f.marketName}
              thanksCount={f.thanksCount}
              aspectRatio="square"
              onClick={() => setSelected(f)}
            />
          ))}
        </div>
      )}

      {/* Empty state */}
      {!loading && finds.length === 0 && (
        <div className="text-center py-8 text-muted-foreground">
          <p className="text-sm">Showing sample finds. Be the first to share!</p>
        </div>
      )}

      <FindDetailPopup isOpen={!!selected} onClose={() => setSelected(null)} find={selected} onToggleThanks={toggleThanks} />
    </div>
  );
}
