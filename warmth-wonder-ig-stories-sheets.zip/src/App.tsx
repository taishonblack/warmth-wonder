import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useEffect, useState } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import Home from "./pages/Home";
import Finds from "./pages/Finds";
import MapPage from "./pages/MapPage";
import Forum from "./pages/Forum";
import Profile from "./pages/Profile";
import UserProfile from "./pages/UserProfile";
import Settings from "./pages/Settings";
import Auth from "./pages/Auth";
import MarketDetail from "./pages/MarketDetail";
import NotFound from "./pages/NotFound";

import nearishLogo from "@/assets/nearish-logo.png";

const queryClient = new QueryClient();

const App = () => {
  const [showSplash, setShowSplash] = useState(() => {
    // Show once per browser session
    return sessionStorage.getItem("nearish_splash_seen") !== "true";
  });

  useEffect(() => {
    if (!showSplash) return;
    const t = setTimeout(() => {
      sessionStorage.setItem("nearish_splash_seen", "true");
      setShowSplash(false);
    }, 850);
    return () => clearTimeout(t);
  }, [showSplash]);

  if (showSplash) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-3 animate-fade-in">
          <img src={nearishLogo} alt="Nearish" className="w-20 h-20 object-contain" />
          <div className="font-serif text-3xl font-bold text-primary">nearish</div>
          <div className="text-sm text-muted-foreground">Find your local good stuff</div>
        </div>
      </div>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AppLayout>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/finds" element={<Finds />} />
            <Route path="/map" element={<MapPage />} />
            <Route path="/forum" element={<Forum />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/u/:userId" element={<UserProfile />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/market/:marketId" element={<MarketDetail />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AppLayout>
      </BrowserRouter>
    </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
