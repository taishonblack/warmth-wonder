import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export type TrustBadge = {
  emoji: string;
  label: string;
  description: string;
};

export function useTrustBadges(userId: string) {
  const [badges, setBadges] = useState<TrustBadge[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!userId) return;

    const run = async () => {
      setLoading(true);
      try {
        // Finds by user
        const { data: finds } = await supabase
          .from("finds")
          .select("id, market_name, created_at")
          .eq("user_id", userId);

        const findCount = finds?.length || 0;
        const distinctMarkets = new Set((finds || []).map((f: any) => f.market_name)).size;

        // Thanks received (all thanks rows for this user's finds)
        const findIds = (finds || []).map((f: any) => f.id);
        let thanksReceived = 0;
        if (findIds.length > 0) {
          const { data: thanks } = await supabase
            .from("thanks")
            .select("find_id")
            .in("find_id", findIds);
          thanksReceived = thanks?.length || 0;
        }

        // Seasonal (last 90 days)
        const cutoff = new Date();
        cutoff.setDate(cutoff.getDate() - 90);
        const seasonalFinds = (finds || []).filter((f: any) => new Date(f.created_at) >= cutoff).length;

        const computed: TrustBadge[] = [];

        if (distinctMarkets >= 10) {
          computed.push({
            emoji: "🌱",
            label: "Local Regular",
            description: "Shared finds across 10+ different markets.",
          });
        }

        if (findCount >= 25) {
          computed.push({
            emoji: "🧭",
            label: "Neighborhood Explorer",
            description: "Posted 25+ finds — you really get around.",
          });
        }

        if (seasonalFinds >= 5) {
          computed.push({
            emoji: "🍂",
            label: "Seasonal Spotter",
            description: "Shared 5+ finds in the last 90 days.",
          });
        }

        if (thanksReceived >= 25) {
          computed.push({
            emoji: "🤝",
            label: "Good Neighbor",
            description: "Received 25+ thanks from the community.",
          });
        }

        if (thanksReceived >= 100) {
          computed.push({
            emoji: "✨",
            label: "Community Favorite",
            description: "Received 100+ thanks on finds.",
          });
        }

        // A small, early badge so new users still feel progression
        if (computed.length === 0 && findCount >= 1) {
          computed.push({
            emoji: "🧺",
            label: "First Find",
            description: "Posted your first community find.",
          });
        }

        setBadges(computed);
      } finally {
        setLoading(false);
      }
    };

    run();
  }, [userId]);

  return { badges, loading };
}
