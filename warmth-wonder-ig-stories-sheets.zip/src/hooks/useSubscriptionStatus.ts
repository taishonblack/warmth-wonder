import { useEffect, useState } from "react";

// MVP: local-only subscription flag.
// Later: replace with Stripe/RevenueCat + Supabase row (e.g. profiles.subscription_status).
const STORAGE_KEY = "nearish_is_subscribed";

export function useSubscriptionStatus() {
  const [isSubscribed, setIsSubscribed] = useState<boolean>(() => {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw === null) return false; // default: browsing free, posting gated
    return raw === "true";
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, String(isSubscribed));
  }, [isSubscribed]);

  return {
    isSubscribed,
    // MVP helpers
    startSubscription: () => setIsSubscribed(true),
    cancelSubscription: () => setIsSubscribed(false),
  };
}
