import { useEffect, useState } from "react";

const STORAGE_KEY = "nearish_location_enabled";

export function useLocationPreference() {
  const [enabled, setEnabled] = useState<boolean>(() => {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw === "true";
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, String(enabled));
  }, [enabled]);

  return {
    enabled,
    enable: () => setEnabled(true),
    disable: () => setEnabled(false),
  };
}
